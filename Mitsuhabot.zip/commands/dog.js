const fetch = require("node-fetch");
const Discord = require('discord.js')

exports.run = async (client, message, args, tools) =>{

let msg = await message.channel.send("กำลังโหลดรูปค่ะ...")

fetch(`https://dog.ceo/api/breeds/image/random`)
    .then(res => res.json()).then(body => {
    if(!body) return message.reply("ขออภัย! ลองใหม่อีกครั้ง!").then(msg => msg.delete(5000));

    let dEmbed = new Discord.RichEmbed()
    .setAuthor(`${message.author.tag} รูปสุนัขของนายท่านค่ะ 🐶`)
    .setImage(body.message)
    .setFooter("ขอรูปโดยนายท่าน " + message.author.tag, message.author.avatarURL)
    .setColor(0xFF0092);

    message.channel.send(dEmbed)
    msg.delete();
});

}