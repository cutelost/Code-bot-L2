exports.run = (client, message, args) =>{
    
    let rMember = message.guild.member(message.mentions.users.first()) || message.guild.members.get(args[0]);
    
    if(!message.member.hasPermission("MANAGE_ROLES_OR_PERMISSIONS")){
        message.channel.send("You don't have the permissions to use this command!");
    }

    else{

        if(!rMember) 
            return message.channel.send("**ขอโทษค่ะ หนูไม่พบชื่อผู้ใช้ที่ต้องการ นายท่านลองดูใหม่อีกครั้งนะคะ 🔍**");

        let role = args.join(" ").slice(22);
        if(!role) 
            return message.channel.send("**นายท่าน กรุณาระบุชื่อบทบาทที่มีอยู่ในเซิฟเวอร์ด้วยค่ะ 🗂️**");

        let gRole = message.guild.roles.find('name', role);
        if(!gRole) 
            return message.channel.send("ขอโทษค่ะ ไม่พบบทบาทที่นายท่านต้องการค่ะ 🔍");


        if(rMember.roles.has(gRole.id)) 
            return message.channel.send("They already have that role.");

        else{
            rMember.addRole(gRole.id).catch(console.error);
            
            try{
                rMember.send(`Congrats, you have been given the role ${gRole.name}`);
                message.channel.send(`The user ${rMember} has a new role ${gRole.name}`);
            }
            catch(e){
                console.log(e.stack);
                message.channel.send(`Congrats to <@${rMember.id}>, they have been given the role ${gRole.name}.`)
            }
        }
    }
}