const Discord = require("discord.js")

exports.run = async (client, message, args, ops) => {

    if (message.author.id !== ops.ownerID) return message.channel.send(`\`${message.author.username}\` คุณไม่สามารถ Reload ได้ คุณไม่มี \`Permission\` แห่งความหล่อ เหมือน 𝓛2`);
    if (!args[0]) return message.channel.send(`\`${message.author.username}\` โปรดระบุคำสั่งเพื่อ reload`);

    try {

        delete require.cache[require.resolve(`./${args[0]}.js`)]
    
    } catch (e) {
        
        return message.channel.send(`ไม่สามารถ reload: \`${args[0]}\` ได้`);
    }
    
    message.channel.send(`คำสั่ง: \`${args[0]}\` ได้รับการ \`reload\` แล้ว`)
}