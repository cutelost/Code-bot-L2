const math = require('mathjs');
const Discord = require('discord.js');

exports.run = async (client, message, args, tools) => {
    
    message.delete(1000);
    if (!args[0]) return message.channel.send(`**${message.author.tag}**`+' ❌ กรุณาใส่ตัวเลขและเครื่องหมายทางคณิตศาสตร์ด้วยค่ะ').then(msg => msg.delete(5000));

    let resp;
    try {
        resp = math.evaluate(args.join(' '));
    } catch (e) {
        return message.channel.send('ขอโทษค่ะ ไม่สามารถตอบได้ 😢').then(msg => msg.delete(5000));
    }

    message.channel.send('**กำลังคิดเลขค่ะ...**').then(async (msg) =>{

    const embed = new Discord.RichEmbed()
    .setColor(0xFF0092)
    .setTitle('เครื่องคิดเลข 💬')
    .addField('คำถาม ❓', `\`\`\`js\n${args.join('')}\`\`\``)
    .addField('คำตอบ ✅', `\`\`\`js\n= ${resp}\`\`\``)

    msg.edit(embed).then(async (msg) =>{

    await msg.react('✅')
    let delay = 0;
msg.createReactionCollector((reaction, user) => reaction.message.id === msg.id && message.author.id == user.id , { time: delay })
.on('collect', async (r) => {
	let eName = r.emoji.name;
    if (eName == '✅') {
	msg.delete(500);
	}
})
    })
    })
}