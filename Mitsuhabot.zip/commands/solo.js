const superagent = require("snekfetch");
const Discord = require('discord.js')

exports.run = async (client, message, args, tools) =>{

if (!message.channel.nsfw) return message.channel.send('นายท่านไม่สามารถใช้คำสั่งนี้ไม่ได้นายท่านต้องเปิด NSFW ค่ะ!')
superagent.get('https://nekos.life/api/v2/img/solo')
    .end((err, response) => {
      const lewdembed = new Discord.RichEmbed()
      .setTitle("Hentai solo จ้าาา")
      .setImage(response.body.url)
      .setColor(0xFF0092)
      .setFooter('ข้อร้องโดยนายท่าน ' + message.author.tag)
      .setURL(response.body.url);
      message.channel.send(lewdembed);
    })

}