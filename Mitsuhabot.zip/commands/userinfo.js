const Discord = require('discord.js');
const moment = require("moment");

const status = {
    online: "ออนไลน์",
    idle: "ไม่อยู่",
    dnd: "ห้ามรบกวน",
    offline: "ออฟไลน์/ไม่ระบุ"
};

exports.run = (client, message, args) =>{
    var permissions = [];
    var acknowledgements = '`ผู้ใช้งานเซิฟเวอร์`';
   
    const member = message.mentions.members.first() || message.guild.members.get(args[0]) || message.member;
    const time = `${moment(member.user.createdAt).fromNow()}`
    
    const randomColor = "#000000".replace(/0/g, function () { return (~~(Math.random() * 16)).toString(16); }); 
  
    if(member.hasPermission("KICK_MEMBERS")){
        permissions.push("🌸 เตะสมาชิก");
    }
    
    if(member.hasPermission("BAN_MEMBERS")){
        permissions.push("🌸 แบนสมาชิก");
    }
    
    if(member.hasPermission("MANAGE_MESSAGES")){
        permissions.push("🌸 จัดการข้อความ");
    }
    
    if(member.hasPermission("MANAGE_CHANNELS")){
        permissions.push("🌸 จัดการแชนแนล");
    }
    
    if(member.hasPermission("MENTION_EVERYONE")){
        permissions.push("🌸 กล่าวถึงทุกคน");
    }

    if(member.hasPermission("MANAGE_NICKNAMES")){
        permissions.push("🌸 จัดการชื่อเล่น");
    }

    if(member.hasPermission("MANAGE_ROLES")){
        permissions.push("🌸 จัดการบทบาท");
    }

    if(member.hasPermission("MANAGE_WEBHOOKS")){
        permissions.push("🌸 จัดการ Webhooks");
    }

    if(member.hasPermission("MANAGE_EMOJIS")){
        permissions.push("🌸 จัดการอีโมจิ");
    }

    if(permissions.length == 0){
        permissions.push("🌸 ไม่มีการอนุญาต");
    }

    if(`<@${member.user.id}>` == message.guild.owner){
        acknowledgements = '`ผู้สร้างเซิฟเวอร์ 👑`';
    }

    if(member.hasPermission("ADMINISTRATOR")){
        if(!member.nickname){
            member.nickname = 'ไม่มีชื่อเล่น'
        }
    const embed = new Discord.RichEmbed()
        .setTitle(`ข้อมูล-ผู้ใช้ 👥`)
        .setDescription('ตำแหน่งในเซิฟเวอร์: '+`${acknowledgements}`)
        .setColor('0xFF0092')
        .setThumbnail(member.user.displayAvatarURL)
        .addField("👤 ชื่อผู้ใช้",`\`\`\`${member.user.tag}\`\`\``, true)
        .addField("🔗 สมาชิก ID",`\`\`\`${member.id}\`\`\``, true)
        .addField("🔒 การอนุญาต", `\`\`\`👑 ผู้ดูแล (ทำได้ทุกอย่าง) 👑\`\`\``)
        .addField('🔖 ชื่อเล่นสมาชิก', `\`\`\`${member.nickname}\`\`\``, true)
        .addField("🌟 สเตตัสผู้ใช้งาน",`\`\`\`${status[member.user.presence.status]}\`\`\``, true)
        .addField('🎁 เข้าเซิฟเมื่อ 📍',`\`\`\`${moment(member.joinedAt).format("DD/MM/YYYY HH:mm:ss (LT)")} ${moment(member.joinedAt).fromNow()}\`\`\``)
        .addField("🎉 สร้างแอคเค้าเมื่อ 📍",`\`\`\`${moment(member.user.createdAt).format("DD/MM/YYYY HH:mm:ss (LT)")} ${moment(member.user.createdAt).fromNow()}\`\`\``)
        
        .addField(`บทบาททั้งหมด [${member.roles.filter(r => r.id !== message.guild.id).map(roles => `\`${roles.name}\``).length}] 📋`,`${member.roles.filter(r => r.id !== message.guild.id).map(roles => `<@&${roles.id }>`).join(" **|** ") || "ไม่พบบทบาท"}`)
        
    message.channel.send({embed});
} else {
    if(!member.nickname){
        member.nickname = 'ไม่มีชื่อเล่น'
    }
const embed = new Discord.RichEmbed()
        .setDescription('ตำแหน่งในเซิฟเวอร์: '+`${acknowledgements}`)
        .setTitle(`User Information :busts_in_silhouette:`)
        .setColor('0xFF0092')
        .setThumbnail(member.user.displayAvatarURL)
        .addField("👤 ชื่อผู้ใช้",`\`\`\`${member.user.tag}\`\`\``, true)
        .addField("🔗 สมาชิก ID",`\`\`\`${member.id}\`\`\``, true)
        .addField("🔒 การอนุญาต", `\`\`\`${permissions.join('\n')}\`\`\``)
        .addField('🔖 ชื่อเล่นสมาชิก', `\`\`\`${member.nickname}\`\`\``, true)
        .addField("🌟 สเตตัสผู้ใช้งาน",`\`\`\`${status[member.user.presence.status]}\`\`\``, true)
        .addField('🎁 เข้าเซิฟเมื่อ 📍',`\`\`\`${moment(member.joinedAt).format("DD/MM/YYYY HH:mm:ss (LT)")} ${moment(member.joinedAt).fromNow()}\`\`\``)
        .addField("🎉 สร้างแอคเค้าเมื่อ 📍",`\`\`\`${moment(member.user.createdAt).format("DD/MM/YYYY HH:mm:ss (LT)")} ${moment(member.user.createdAt).fromNow()}\`\`\``)
        
        .addField(`บทบาททั้งหมด [${member.roles.filter(r => r.id !== message.guild.id).map(roles => `\`${roles.name}\``).length}] 📋`,`${member.roles.filter(r => r.id !== message.guild.id).map(roles => `<@&${roles.id }>`).join(" **|** ") || "ไม่พบบทบาท"}`)
        
    message.channel.send({embed});
}
}