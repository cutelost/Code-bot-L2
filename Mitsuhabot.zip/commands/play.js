const Discord = require('discord.js')


exports.run = async (client, message, args, tools) =>{
    message.delete(1000);
    const embed = new Discord.RichEmbed()
    .setTitle('::ฟังก์ชั่นเล่นเพลงตอนนี้ยังไม่สามารถใช้งานได้::')
    .setDescription(`❌เนื่องจากตอนนี้บอทกำลังอยู่ในช่วงพัฒนาอยู่\nดังนั้นจึงไม่สามารถใช้คำสั่งนี้ในช่วงระยะเวลาหนึ่ง\nโปรดรอประกาศจากทางทีมงานแจ้งให้ทราบภายหลัง`)
    //.setThumbnail('')
    .addField('สามารถติดตามข่าวการอัพเดทก่อนใครได้ที่ 📨', `\`Dicord\` [ดิสคอร์ด:](https://discord.gg/3FP2hZ8) ­ ­ ­ ­ ­ ­ ­ ­  ­ ­ ­  ­ ­ ­  ­ ­ ­ ­\`Invite\` [เชิญบอท:](https://discordapp.com/oauth2/authorize?client_id=602121432620728350&scope=bot&permissions=8)`)
    .addField('สถานะบอท', 'Developing', true)
    .addField('­ ­ ­ ­ ผู้สร้างบอทและผู้ช่วย', '𝓛2#8341 & Yuno#3803', true)
    .setColor('ca0000')
    .setTimestamp()
    .setFooter('ขออภัยในความไม่สะดวกนะคะ')

    let msg = await message.channel.send(embed);

    await msg.react('✅')
    let delay = 0;
msg.createReactionCollector((reaction, user) => reaction.message.id === msg.id && message.author.id == user.id , { time: delay*20 })
.on('collect', async (r) => {
	let eName = r.emoji.name;
    if (eName == '✅') {
	msg.delete(500);
	}
})

}