exports.run = (client, message, args) => {
    let member = message.mentions.members.first() || message.guild.members.get(args[0]);
    
    message.delete();
    if(!message.member.hasPermission("KICK_MEMBERS")){
        message.channel.send(`**${message.author.tag}**`+" ❌ | คุณไม่มีสิทในการเตะดังนั้นจึงไม่สามารถใช้คำสั่งนี้ได้ค่ะ!").then(msg => msg.delete(5000));
    }
    else{
        message.delete();
        if(!member)
            //you have to type !kick then @username#1234 as an example
            return message.channel.send(`**${message.author.tag}**`+" ❌ | โปรดระบุชื่อผู้ใช้ที่จะเตะในครั้งต่อไป").then(msg => msg.delete(5000));
        message.delete();
        if(!member.kickable) 
            return message.channel.send("หนูไม่สามารถเตะผู้ใช้รายนี้ได้! อาจเพราะมีบทบาทที่สูงกว่าหรือ หนูไม่มีสิทธิ์ในการเตะ 😥").then(msg => msg.delete(5000));

        // slice(1) removes the first part, which here should be the user mention or ID
        // join(' ') takes all the various parts to make it a single string.
        message.delete();
        let reason = args.slice(1).join(' ');
        if(!reason) 
            reason = "ไม่มีเหตุผล";
        member.kick(reason)
            .catch(error => message.channel.send(`ขอโทษค่ะ ${message.author} หนูไม่สามารถเตะได้เพราะ: ${error}`)).then(msg => msg.delete(5000));
            message.channel.send(`${member.user.tag} โดนเตะโดย ${message.author.tag} เหตุผล: ${reason}`);
    }
}