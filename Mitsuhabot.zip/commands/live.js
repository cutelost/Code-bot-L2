const Discord = require("discord.js");


exports.run = (client, message, args, tools) =>{

    let vcid = message.member.voiceChannelID;

    if (!vcid) return message.channel.send('หนูขอโทษค่ะ นายท่านต้องอยู่ในห้องคอลก่อนถึงจะสามารถใช้คำสั่งนี้ได้นะคะ 😜').then(msg => msg.delete(5000));

        const embed = new Discord.RichEmbed()
         .setColor('0xFF0092')
         .setAuthor(`𝐌𝐢𝐭𝐬𝐮𝐡𝐚'𝐋𝐢𝐯𝐞🌸`, message.guild.iconURL)
         //.setThumbnail(sicon)
         .addField('กดข้างล้างเพื่อชมการแชร์ `คำสั่งนี้ใช้ได้บน PC เท่านั้น`', `[🎁: กดตรงนี้เพื่อดูการแชร์ ${message.member.voiceChannel}](https://www.discordapp.com/channels/${message.guild.id}/${message.member.voiceChannelID})`)
        message.channel.send(embed);
    
}