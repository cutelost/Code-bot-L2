const Discord = require('discord.js')


exports.run = async (client, message, args, tools) =>{

    if (message.author.bot) return;
    message.delete();
    if (!args.slice(0).join(' ')) return message.channel.send(`**${message.author.tag}**`+' โปรดใส่ข้อความที่ต้องการจะประกาศด้วยค่ะ').then(msg => msg.delete(5000));

    message.delete();
    message.channel.send(args.slice(0).join(' '));
    


}