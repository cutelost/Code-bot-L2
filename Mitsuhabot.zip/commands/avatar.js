const Discord = require('discord.js')

 
exports.run = async (client, message, args, tools) =>{

    const member = message.mentions.members.first() || message.guild.members.get(args[0]) || message.member;

    let msg = await message.channel.send("กำลังโหลดอวตารค่ะ...");
    let mentionedUser = message.mentions.users.first() || message.author;

        let embed = new Discord.RichEmbed()

        .setImage(mentionedUser.displayAvatarURL)
        .setColor("0xFF0092")
        .setTitle("รูปของคุณค่ะ")
        .setFooter("ค้นหาโดยนายท่าน " + message.author.tag)
        .setDescription(`${member.user.tag}`+" | [ลิงค์ URL ของรูปคุณจ้า]("+mentionedUser.displayAvatarURL+")");

        message.channel.send(embed)

    msg.delete();
}