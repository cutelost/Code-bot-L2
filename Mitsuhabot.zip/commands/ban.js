exports.run = (client, message, args) => {
    let member = message.mentions.members.first() || message.guild.members.get(args[0]);

    message.delete();
    if(!message.member.hasPermission("BAN_MEMBERS")){
        message.channel.send(`**${message.author.tag}**`+" ❌ | คุณไม่มีสิทในการแบนดังนั้นจึงไม่สามารถใช้คำสั่งนี้ได้ค่ะ!").then(msg => msg.delete(5000));
    }

    else{
        message.delete();
        if(!member)
            return message.channel.send(`**${message.author.tag}**`+" ❌ | โปรดระบุชื่อผู้ใช้ที่จะแบนในครั้งต่อไป").then(msg => msg.delete(5000));
        message.delete();
        if(!member.bannable) 
            return message.channel.send("หนูไม่สามารถแบนผู้ใช้รายนี้ได้! อาจเพราะมีบทบาทที่สูงกว่าหรือ หนูไม่มีสิทธิ์ในการแบน 😥").then(msg => msg.delete(5000));

        message.delete();
        let reason = args.slice(1).join(' ');
        if(!reason) reason = "ไม่มีเหตุผล";
        
        member.ban(reason)
        .catch(error => message.channel.send(`ขอโทษค่ะ ${message.author} หนูไม่สามารถแบนผู้ใช้นี้ได้ค่ะ`)).then(msg => msg.delete(5000));
        message.channel.send(`${member.user.tag} โดนแบนโดย ${message.author.tag} เหตุผล: ${reason}`);
    }
}