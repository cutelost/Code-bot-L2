const fetch = require("node-fetch");
const Discord = require('discord.js')

exports.run = async (client, message, args, tools) =>{

let msg = await message.channel.send("กำลังโหลดรูปค่ะ...")

fetch(`http://aws.random.cat/meow`)
    .then(res => res.json()).then(body => {
    if(!body) return message.reply("ขออภัย! ลองใหม่อีกครั้ง!").then(msg => msg.delete(5000));

    let cEmbed = new Discord.RichEmbed()
    .setAuthor(`${message.author.tag} รูปแมวค่ะ 🐱`)
    .setImage(body.file)
    .setFooter("ขอรูปโดยนายท่าน " + message.author.tag, message.author.avatarURL)
    .setColor(0xFF0092);

    message.channel.send(cEmbed)
    msg.delete();
});

}