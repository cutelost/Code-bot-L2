const Discord = require('discord.js');

const agree    = "✅";
const disagree = "❎";


exports.run = (client, message, args, tools) => {
  
    message.delete()
    if (!message.member.hasPermission("KICK_MEMBERS")){
      return message.channel.send(`**${message.author.tag}**`+' ❌ | คุณไม่มีสิทในการเตะดังนั้นจึงไม่สามารถใช้คำสั่งนี้ได้ค่ะ!').then(msg => msg.delete(5000));
    }

    if (message.mentions.users.size === 0){
        return message.channel.send(`**${message.author.tag}**`+" ❌ | โปรดระบุผู้ใช้ที่จะเตะในครั้งต่อไป").then(msg => msg.delete(5000));
    }
    
      let kickmember = message.guild.member(message.mentions.users.first());
      if(!kickmember){
        message.channel.send(`**${message.author.tag}**`+" ❌ | ผู้ใช้รายนั้นดูเหมือนไม่ถูกต้อง!").then(msg => msg.delete(5000));
    }
    
      if(!message.guild.member(client.user).hasPermission("KICK_MEMBERS")){
        return message.channel.send(`**${message.author.tag}**`+" ❌ | หนูต้องการสิท \"KICK_MEMBERS\" การอนุญาต!").catch(console.error).then(msg => msg.delete(5000));
    }

    let mentionedUser = message.mentions.users.first() || message.author;
    
    if (!args.slice(1).join(' ')) return message.channel.send(`**${message.author.tag}**`+' ❌ | กรุณาใส่เหตุผลที่จะเตะด้วยค่ะ').then(msg => msg.delete(5000));

    const embed = new Discord.RichEmbed()

        .setAuthor(`${message.author.tag} ได้ทำการโหวตเตะ`, message.author.avatarURL)
        .setThumbnail(mentionedUser.displayAvatarURL)
        .setDescription("โหวตตอนนี้! มีเวลา`[60 วินาที]` 🔗")
        .addField(`เหตุผลการเตะ 📝:`, `\n${args.slice(1).join(' ')}`)
        .setTimestamp()
        .setColor('0xFF0092')
        .setFooter('กรุณากด รีแอคชั่น เพื่อโหวตการนะคะ')

      message.channel.send(embed).then(async (msg) =>{

      await msg.react(agree);
      await msg.react(disagree);
    
      const reactions = await msg.awaitReactions(reaction => reaction.emoji.name === agree || reaction.emoji.name === disagree, {time: 60000});
      msg.delete();
    
      var NO_Count = reactions.get(disagree).count;
      var YES_Count = reactions.get(agree);
    
      if(YES_Count == undefined){
        var YES_Count = 1;
      }else{
        var YES_Count = reactions.get(agree).count;
    }
    
      var sumsum = new Discord.RichEmbed()
                .setDescription('📊 ผลจากการโหวต 📊')
                .addField("❌เสร็จสิ้นการลงคะแนน❌", "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" +
                                              "\n­" +
                                              "­[✅]: จำนวนโหวตทั้งหมด [เตะ]: " + `${YES_Count-1}\n` +
                                              "[❎]: จำนวนโหวตทั้งหมด [ไม่เตะ]: " + `${NO_Count-1}\n` +
                                              "\n­" +
                                              "­[📋]: จำเป็นต้องโหวต 3 คนขึ้นไปถึงจะสามารถเตะได้\n" +
                                              "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", true)
                .setTimestamp()
                .setFooter("เปิดโหวตโดยนายท่าน " + message.author.tag, message.author.avatarURL)
                .setColor("0xFF0092")
    
      await message.channel.send({embed: sumsum});
    
      if(YES_Count >= 3 && YES_Count > NO_Count){
    
        kickmember.kick().then(member => {
          message.channel.send(`${member.user.username} ถูกเตะแล้วจ้าาา`)
        })
      }else{
    
        message.channel.send(`${mentionedUser} ` + "ปลอดภัย ..... สำหรับตอนนี้").then(msg => msg.delete(5000));
      }
    
    })
    }
    