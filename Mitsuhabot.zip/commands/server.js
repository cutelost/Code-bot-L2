const Discord = require('discord.js');
const moment = require('moment');

exports.run = (client, message, args, tools) =>{
    function checkBots(guild) {
        let botCount = 0;
        guild.members.forEach(member => {
            if(member.user.bot) botCount++;
        });
        return botCount;
    }
    
    function checkMembers(guild) {
        let memberCount = 0;
        guild.members.forEach(member => {
            if(!member.user.bot) memberCount++;
        });
        return memberCount;
    }

    function checkOnlineUsers(guild) {
        let onlineCount = 0;
        guild.members.forEach(member => {
            if(member.user.presence.status === "online")
                onlineCount++; 
        });
        return onlineCount;
    }

    if(message.guild.verificationLevel == 0){
        message.guild.verificationLevel = 'ไม่มี (ไม่จำกัด)'
    } else if(message.guild.verificationLevel == 1){
        message.guild.verificationLevel = 'ต่ำ'
    } else if(message.guild.verificationLevel == 2){
        message.guild.verificationLevel = 'ปานกลาง'
    } else if(message.guild.verificationLevel == 3){
        message.guild.verificationLevel = 'สูง'
    } else if(message.guild.verificationLevel == 4){
        message.guild.verificationLevel = 'สูงมาก'
    }


    let sicon = message.guild.iconURL;
    let serverembed = new Discord.RichEmbed()
        .setTitle(`ข้อมูล-เซิฟเวอร์ 📊`)
        .setDescription(`เจ้าของเซิฟเวอร์ 👑 ${message.guild.owner}`)
        .setColor("0xFF0092")
        .setThumbnail(sicon)
        .addField("🏡 ชื่อเซิฟเวอร์ 📌", `\`\`\`${message.guild.name}\`\`\``)
        .addField('🔗 ไอดีเซิร์ฟเวอร์', `\`\`\`${message.guild.id}\`\`\``)
        .addField('🌎 พื้นที่เซิร์ฟเวอร์', `\`\`\`${message.guild.region}\`\`\``, true)
        
        .addField('🌸 สมาชิกทั้งหมด', `\`\`\`${message.guild.memberCount}\`\`\``, true)
        .addField('🕵️‍♂️ สมาชิกที่เป็นคน', `\`\`\`${checkMembers(message.guild)}\`\`\``, true)
        .addField('🤖 สมาชิกที่เป็นบอท', `\`\`\`${checkBots(message.guild)}\`\`\``, true)
        .addField('🌟 สมาชิกออนไลน์', `\`\`\`${checkOnlineUsers(message.guild)}\`\`\``, true)
        .addField('🚪 ห้องทั้งหมด', `\`\`\`${message.guild.channels.size}\`\`\``, true)
        .addField('🛡️ ระดับการยืนยันตัวตน', `\`\`\`${message.guild.verificationLevel}\`\`\``, true)
        .addField('📋 บทบาททั้งหมด', `\`\`\`${message.guild.roles.size}\`\`\``, true)
        .addField('เซิฟเวอร์ถูกสร้างเมื่อวันที่', `\`\`\`${moment(message.guild.createdAt).format("DD/MM/YYYY HH:mm:ss (LT)")} ${moment(message.guild.createdAt).fromNow()}\`\`\``)

    return message.channel.send(serverembed);
}