const Discord = require('discord.js')

 
exports.run = async (client, message, args, tools) =>{

		message.delete();
        const embedhelp = new Discord.RichEmbed()
                .setAuthor(`🌸𝐌𝐢𝐭𝐬𝐮𝐡𝐚'𝐜𝐨𝐦𝐦𝐚𝐧𝐝`)
		.setTitle('HELP MENU')
		.addField('⭐: กลับหน้าหลัก', '[กลับคืนสู่หน้าเมนูคำสั่ง help]')
		.addField('🔧: ระบบเซิฟเวอร์ ', ' [รายละเอียด] : เป็นระบบเกียวกับการตั้งค่าบอทการตั้งการทำงานบอทต่างๆหรือระบบป้องกันต่างๆหรือคำสั่งแอดมินจะรวมในนี้ด้วย!')
		.addField('🎀: ระบบทั่วไป ', ' [รายละเอียด] : เป็นระบบเกียวกับระบบทั่วไปที่บอทต่างใช้กันนะครับ!')
		.addField('🎵: เปิดเพลง ', ' [รายละเอียด] : เป็นระบบเกียวกับการเปิดเพลงฟังมีระบบพิมไทยได้นะงับผมเราจะบอกรายละเอียดการเล่นเพลงต่างแค่พิมว่าLmusicนะครับ!')
		.addField('🎮: เล่นเกมส์ ', ' [รายละเอียด] : เป็นระบบเกียวกับการเล่นมินิเกมสฺ์ในดิสหรือในตัวของบอทนะครับมีมินิเกมส์แน่นอนครับ!')
		.addField('📷: รูปภาพ ', ' [รายละเอียด] : เป็นระบบเกียวกับการแจกรูปหรือรูป18+หรือจะเป็นเกียวกับGifหรือความรู้สึกต่างๆจะอยู่ในระบบนี้นะครับ!')
		.addField('📰: ข่าวสาร ', ' [รายละเอียด] : เป็นระบบเกียวกับการประกาศข่าวสารต่างเช่นการ์ตูนหรืออย่างอื่นนะครับ!')
		.addField(`🎁: ดิสคอสซัพพอร์ต`, `[คลิกเลย](https://discord.gg/3FP2hZ8)`, true)
		.addField(`🎁: เชิญบอท`, `[คลิกเลย](https://discordapp.com/oauth2/authorize?client_id=602121432620728350&scope=bot&permissions=8)`, true)
		.setTimestamp()
		.setImage(`https://cdn.discordapp.com/attachments/548522973385195531/639115953816207371/MENUHELP.png`)
        .setFooter("ข้อร้องโดยนายท่าน " + message.author.tag, message.author.avatarURL)
        .setColor(0xFF0092);
				message.channel.send(embedhelp).then(async (msg) =>{
					await msg.react('⭐')
					await msg.react('🔧')
					await msg.react('🎀')
					await msg.react('🎵')
					await msg.react('🎮')
					await msg.react('📷')
					await msg.react('📰')
					await msg.react('❌')
					let delay = 3000;
msg.createReactionCollector((reaction, user) => reaction.message.id === msg.id && message.author.id == user.id , {max: 0, time: 0 })
.on('collect', async (r) => {
	let eName = r.emoji.name;
	if (eName == '⭐') {
        const embedhelp = new Discord.RichEmbed()
                .setAuthor(`🌸𝐌𝐢𝐭𝐬𝐮𝐡𝐚'𝐜𝐨𝐦𝐦𝐚𝐧𝐝`)
		.setTitle('HELP MENU')
		.addField('⭐: กลับหน้าหลัก', '[กลับคืนสู่หน้าเมนูคำสั่ง help]')
		.addField('🔧: ระบบเซิฟเวอร์ ', ' [รายละเอียด] : เป็นระบบเกียวกับการตั้งค่าบอทการตั้งการทำงานบอทต่างๆหรือระบบป้องกันต่างๆหรือคำสั่งแอดมินจะรวมในนี้ด้วย!')
		.addField('🎀: ระบบทั่วไป ', ' [รายละเอียด] : เป็นระบบเกียวกับระบบทั่วไปที่บอทต่างใช้กันนะครับ!')
		.addField('🎵: เปิดเพลง ', ' [รายละเอียด] : เป็นระบบเกียวกับการเปิดเพลงฟังมีระบบพิมไทยได้นะงับผมเราจะบอกรายละเอียดการเล่นเพลงต่างแค่พิมว่าLmusicนะครับ!')
		.addField('🎮: เล่นเกมส์ ', ' [รายละเอียด] : เป็นระบบเกียวกับการเล่นมินิเกมสฺ์ในดิสหรือในตัวของบอทนะครับมีมินิเกมส์แน่นอนครับ!')
		.addField('📷: รูปภาพ ', ' [รายละเอียด] : เป็นระบบเกียวกับการแจกรูปหรือรูป18+หรือจะเป็นเกียวกับGifหรือความรู้สึกต่างๆจะอยู่ในระบบนี้นะครับ!')
		.addField('📰: ข่าวสาร ', ' [รายละเอียด] : เป็นระบบเกียวกับการประกาศข่าวสารต่างเช่นการ์ตูนหรืออย่างอื่นนะครับ!')
		.addField(`🎁: ดิสคอสซัพพอร์ต`, `[คลิกเลย](https://discord.gg/3FP2hZ8)`, true)
		.addField(`🎁: เชิญบอท`, `[คลิกเลย](https://discordapp.com/oauth2/authorize?client_id=602121432620728350&scope=bot&permissions=8)`, true)
		.setTimestamp()
		.setImage(`https://cdn.discordapp.com/attachments/548522973385195531/639115953816207371/MENUHELP.png`)
        .setFooter("ข้อร้องโดยนายท่าน " + message.author.tag, message.author.avatarURL)
        .setColor(0xFF0092);
				msg.edit(embedhelp)

			} else if (eName == '🎵') {
		const embedsong = new Discord.RichEmbed()
		.setAuthor(`🌸𝐌𝐢𝐭𝐬𝐮𝐡𝐚'𝐜𝐨𝐦𝐦𝐚𝐧𝐝`)
		.setTitle('HELP MUSIC MENU')
		.addField(`เวอร์ชั้น`, `1.0.0`, true)
		.addField(`ผู้สร้างจ้าา`, `𝓛2#8341`, true)
		.addField('MENU', `
		L!play , L!เปิดเพลง <ชื่อเพลง | URL เพลง> - เล่นเพลงที่มีให้
L!stop , L!ปิดเพลง - หยุดเพลงปัจจุบันและล้างคิว
L!skip , L!เปลี่ยนเพลง - ข้ามเพลงปัจจุบัน
L!pause , L!หยุด - หยุดเพลงปัจจุบันชั่วคราว
L!resume , L!ต่อ - เล่นเพลงต่อจากการหยุด
L!queue , L!คิว - แสดงคิวเพลงทั้งหมด
L!volume , L!เสียง [1 > 5] - ปรับระดับเสียงของเพลง
L!loop , L!วน [on | off] - เพิ่มเพลงในคิวอีกครั้งเมื่อเสร็จสิ้น`)
		.setTimestamp()	
        .setFooter("ข้อร้องโดยนายท่าน " + message.author.tag, message.author.avatarURL)
		.setColor(0xFF0092);
				msg.edit(embedsong)

			} else if (eName == '📷') {
				const embedpic = new Discord.RichEmbed()
			.setAuthor(`🌸𝐌𝐢𝐭𝐬𝐮𝐡𝐚'𝐜𝐨𝐦𝐦𝐚𝐧𝐝`)
			.setTitle('HELP MUSIC MENU')
			.addField(`เวอร์ชั้น`, `1.0.0`, true)
			.addField(`ผู้สร้างจ้าา`, `𝓛2#8341`, true)
			.addField('MENU', `
            L!cat - สุ่มหาภาพน้องแมว
L!dog - สุ่มหาภาพน้องหมา
L!solo - สุ่มหาภาพ Hentai 18+
L!neko - สุ่มหาภาพ Hentai Neko 18+
L!avatar - ดูรูปโปรไฟล์ของตัวเอง
L!avatar [@ชื่อเพื่อน] - ดูรูปโปรไฟล์ของคนอื่น`)
				.setTimestamp()
.setFooter("ข้อร้องโดยนายท่าน " + message.author.tag, message.author.avatarURL)
				.setColor(0xFF0092);
				msg.edit(embedpic)

			} else if (eName == '❌') {
				msg.delete()
				const embedexit = new Discord.RichEmbed()
			.setTitle(`ขอบคุณนายท่านที่เรียกใช้ค่ะ 😊`)
			.addField(`ดิสตอสเราจ้า`, `[Mitsuha'official](https://discord.gg/3FP2hZ8)`, true)
			.addField(`ผู้สร้างจ้าา`, `𝓛2#8341`, true)
            .setFooter("ไว้เรียกใช้ใหม่อีกครั้งนะคะ ✅", client.user.avatarURL)
			.setColor(0xFF0092);
				message.channel.send(embedexit).then(async (msg) =>{
				msg.react('✅')
msg.createReactionCollector((reaction, user) => reaction.message.id === msg.id && message.author.id == user.id , { time: 0 })
.on('collect', async (r) => {
				let eName = r.emoji.name;
				if (eName == '✅') {
					msg.delete(700);
				}
				})
				})
			}  
		}
					)}
					)}