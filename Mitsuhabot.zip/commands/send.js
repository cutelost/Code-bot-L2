const Discord = require('discord.js')


exports.run = async (client, message, args, tools) =>{
    
    message.delete();
    if (message.author.client) return message.channel.send('ขอโทษนะคะ หนูไม่สามารถส่งข้อความได้ค่ะ 😟').then(msg => msg.delete(5000));

    let mention = message.mentions.users.first() || message.author;
    
    if (!args[0]) return message.channel.send(`**${message.author.tag}**`+' กรุณาแท็กชื่อคนที่ต้องการจะส่งข้อความด้วยค่ะ..').then(msg => msg.delete(5000));
    if (!args.slice(1).join(' ')) return message.channel.send(`**${message.author.tag}**`+' โปรดใส่ข้อความที่ต้องการจะเขียนด้วยค่ะ..').then(msg => msg.delete(5000));

    if (mention == null) { return; }

try {
    mentionMessage = message.content.slice(8);
    mention.sendMessage('💌 ข้อความจากคุณ'+`**${message.author.tag}**`+' ส่งมาว่า: '+`**${args.slice(1).join(' ')}**`+``);
    message.channel.send("✉️ ข้อความส่งถึงมือคนรับเรียบร้อยค่ะ 😊");
} catch (e) {
    return message.channel.send('ขอโทษนะคะ หนูไม่สามารถส่งข้อความได้ค่ะ 😟')
}
}