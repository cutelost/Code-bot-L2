const Discord = require('discord.js')

 
exports.run = async (client, message, args, tools) =>{

    message.channel.send('**กำลังโหลดข้อมูลค่ะ...**').then(async (msg) =>{

    let ping = msg.createdTimestamp - message.createdTimestamp

    const embed = new Discord.RichEmbed()
    .setAuthor(`𝐌𝐢𝐭𝐬𝐮𝐡𝐚 𝐈𝐧𝐟𝐨🌸`, client.user.avatarURL)
    .addField(`เชิญบอท 📥`, `[Mitsuha'Invite](https://discordapp.com/oauth2/authorize?client_id=602121432620728350&scope=bot&permissions=8)`, true)
    .addField(`ดิสที่เข้า 📊`, `**${client.guilds.size} เซิฟ**`, true)
    .addField(`ผู้ใช้ทั้งหมด 👤`, `**${client.users.size} คน**`, true)
    .addField(`ดิสตอสเรา 🌸`, `[Mitsuha'Discord](https://discord.gg/3FP2hZ8)`, true)
    ///.setThumbnail(client.user.avatarURL)
    .setImage(`https://i.pinimg.com/564x/a0/dd/e2/a0dde2d6d1ed8d070ecdde556288f1e8.jpg`)
    .addField(`เวอร์ชั้น 🏷️`, `**1.0.0**`, true)
    .addField(`ค่าความหน่วง 📶`,`**${ping} ms!**`,true)
    .addField(`ผู้สร้าง 👑`, `**𝓛2#8341**`, true)
    .addField(`ผู้ช่วย 👑`, `**Yuno#3803**`, true)
    .addField(`แท็ก 📌`, `<@${client.user.id}>`, true)
	.setTimestamp()
    .setFooter(`BOT ID: `+`${client.user.id}`)
    .setColor(0xFF0092);
    
    msg.edit(embed)

    })
}