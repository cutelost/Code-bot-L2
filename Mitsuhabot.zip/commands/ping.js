const Discord = require('discord.js')
const moment = require("moment");
const timestamp = `[${moment().format("YYYY-MM-DD HH:mm:ss")}]:`;

exports.run = async (client, message, args, tools) => {

	message.channel.send('**กำลังโหลดข้อมูลค่ะ...**').then(async (msg) =>{

	let pings = msg.createdTimestamp - message.createdTimestamp
    
	const embed = new Discord.RichEmbed()
	.setColor('0097ff')
	.setAuthor('ค่าความหน่วงของนายท่านค่ะ ☑️')
	.setDescription(`Ping Latency: \`${pings}\` ms! 📶 | API Latency: \`${Math.round(client.ping)}\` ms! 📶`)
	
    msg.edit(embed);
	//msg.edit(`Message roundtrip took: \`${pings}ms\` BotPing: \`${Math.round(client.ping)}ms\``);
	
	})
	}