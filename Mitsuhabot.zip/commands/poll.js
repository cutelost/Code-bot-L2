const Discord = require('discord.js');

exports.run = async (client, message, args, tools) => {

    //if (!message.member.roles.find(r => r.name === 'roleName')) return message.channel.send('This requires the role: roleName');
    if (!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send(`**${message.author.tag}**`+' คุณจำเป็นต้องมีสิท: ADMINISTRATOR ถึงจะใช้คำสั่งได้').then(msg => msg.delete(5000));
    if (!args[0]) return message.channel.send(`**${message.author.tag}**`+' กรุณาเขียนโพลล์ที่ต้องการ หลังคำสั่ง').then(msg => msg.delete(5000));
    message.delete();
    const embed = new Discord.RichEmbed()
        .setColor('0xFF0092')
        .setFooter('กรุณากด รีแอคชั่น เพื่อโหวต')
        .setDescription('คำถาม: '+ args.join(' ')+'❓')
        .setTitle(` โพลล์โดย ${message.author.username}  💬`);

    let msg = await message.channel.send(embed);

    await msg.react('✅')
    await msg.react('❎')
    await msg.react('❌')
    msg.createReactionCollector((reaction, user) => reaction.message.id === msg.id && message.author.id == user.id , {max: 0, time: 0 })
    .on('collect', async (r) => {
        let eName = r.emoji.name;
        if (eName == '❌') {
            msg.delete();
            message.channel.send(`**${message.author.tag}**`+' ขอบคุณที่เรียกใช้งานนะคะ 😊').then(msg => msg.delete(7000));
        }
    })
    
}