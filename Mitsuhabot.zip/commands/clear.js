const Discord = require('discord.js')

exports.run = (client, message, args) =>{
    const deleteCount = parseInt(args[0], 10);
    async function clear() {
        message.delete();
        if(!message.member.hasPermission("MANAGE_MESSAGES")){
          message.channel.send(`**${message.author.tag}**`+" คุณไม่ได้รับการอนุญาตในการใช้คำสั่งนี้ค่ะ!").then(msg => msg.delete(5000));
        }
        
        else{        

          if(!deleteCount || deleteCount < 2 || deleteCount > 100)
            return message.channel.send(`**${message.author.tag}**`+" โปรดระบุหมายเลขระหว่าง 2 ถึง 100 เพื่อเลือกจำนวนข้อความที่จะลบค่ะ").then(msg => msg.delete(5000));
          
          
          const fetched = await message.channel.fetchMessages({limit: deleteCount});
          message.channel.bulkDelete(fetched).catch(error => message.channel.send(`**${message.author.tag}**`+`ไม่สามารถลบข้อความเนื่องจาก: ${error}`)).then(msg => msg.delete(5000));
          message.channel.send(`ลบข้อความจำนวน \`${deleteCount}\` เสร็จสิ้น ขอบคุณที่เรียกใช้งานนะคะ 😊`).then(msg => msg.delete(5000));
        }
    }
    clear();
}