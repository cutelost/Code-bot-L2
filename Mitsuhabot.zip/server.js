﻿const Discord = require('discord.js')
const moment = require("moment");
const chalk = require("chalk");
const fs = require('fs');
const client = new Discord.Client();

const token = 'NjAyMTIxNDMyNjIwNzI4MzUw.XbmAvw.MYQbTxo50KTO0hLMuDY-o3LU8oE' // Token Mitsuha
const prefix = 'L!' // Prefix Mitsuha
//const ownerID = '577834352625319936' //yunoID
const ownerID = '287945376366067712' //L2ID

const cooldown = new Set();
const cds = 5;
const timestamp = `${chalk.hsl(32, 100, 50).bold(`[${moment().format("YYYY-MM-DD")}]`)}:`;

client.login(token)

client.on('message', message => {

    let args = message.content.substring(prefix.length).split(' ');
    let cmd = args.shift().toLowerCase();

    if (message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;

    if (cooldown.has(message.author.id)){
        message.delete();
        return message.channel.send(`**นายท่านต้องรอ \`${cds}\` วินาทีก่อนที่จะใช้คำสั่งครั้งต่อไปค่ะ**`).then(msg => msg.delete(5000));
    }
    if (!message.member.hasPermission("ADMINISTRATOR")){
        cooldown.add(message.author.id);
    }

    setTimeout(() => {
        cooldown.delete(message.author.id)
    }, cds * 1000)

    if(!cmd) return message.channel.send(`กรุณาใส่คำสั่งที่ต้องการจะเรียกใช้ด้วยค่ะหรือถ้ายังไม่รู้คำสั่งใดๆเลยให้พิม \`${prefix}help\` เพื่อดูคำสั่งนะคะ 😊`).then(msg => msg.delete(10000));
    try {

        delete require.cache[require.resolve(`./commands/${cmd}.js`)];
        
        // Options
        let ops = {
            ownerID: ownerID
        }
        
        let commandFile = require(`./commands/${cmd}.js`);
        commandFile.run(client, message, args, ops);
    } catch (e) {
        return message.channel.send(`ไม่พบคำสั่งที่นายท่านต้องการเรียกใช้ โปรดใส่คำสั่งให้ถูกต้องด้วยค่ะ 🔍`).then(msg => msg.delete(5000));
    }
});

client.on('ready', () => {
    console.log(`${timestamp}Now ${chalk.hex('#ff005a').bold(`${client.user.tag}`)} is awake with ${chalk.hex('#00ff4a').bold(`${client.users.size}`)} users of ${chalk.cyanBright.bold(`${client.guilds.size}`)} guilds.`)

client.user.setActivity(
    `Mitsuha ตื่นแล้วจ้าา`,
    { type: 'PLAYING' }
);

    setInterval( () => {
        const statuslist = [
            `L!help | ${client.guilds.size} ดิสที่เข้าจ้าา`,
            `L!help | ${client.users.size} ผู้ใช้งาน`,
            `L!help | บอทอยู่ในช่วงทดสอบ`,
			`L!help | by 𝓛2#8341`
        ];

        client.user.setActivity(
        `${statuslist[Math.floor(Math.random() * statuslist.length)]}`,
        { type: 'PLAYING' }
        );
    }, 10000);
    
})

const botStats = {
    totalGuildsID: '652385147093647370',
    totalUsersID: '652384709103321099',
    totalChannelsID: '652385211518156830'
  };
  
  client.on('guildCreate', guild => {
  
    client.channels.get(botStats.totalGuildsID).setName(`🌸ดิสคอร์ดที่เข้า : ${client.guilds.size}`);
    //client.channels.get(botStats.totalUsersID).setName(`🌸ผู้ใช้ทั้งหมด : ${client.guilds.reduce((a, g) => a + g.memberCount, 0)}`);
    client.channels.get(botStats.totalUsersID).setName(`🌸ผู้ใช้ทั้งหมด : ${client.users.size}`);
    client.channels.get(botStats.totalChannelsID).setName(`🌸ห้องทั้งหมด : ${client.channels.size}`);
    console.log(`${timestamp}${chalk.hex('#ff005a').bold('Mitsuha')}:> Guilds update now ${chalk.cyan.bold(`${client.guilds.size}`)} server.`)
  });
  
  client.on('guildDelete', guild => {
  
    client.channels.get(botStats.totalGuildsID).setName(`🌸ดิสคอร์ดที่เข้า : ${client.guilds.size}`);
    //client.channels.get(botStats.totalUsersID).setName(`🌸ผู้ใช้ทั้งหมด : ${client.guilds.reduce((a, g) => a + g.memberCount, 0)}`);
	client.channels.get(botStats.totalUsersID).setName(`🌸ผู้ใช้ทั้งหมด : ${client.users.size}`);
    client.channels.get(botStats.totalChannelsID).setName(`🌸ห้องทั้งหมด : ${client.channels.size}`);
    console.log(`${timestamp}${chalk.hex('#ff005a').bold('Mitsuha')}:> Guilds update now ${chalk.cyan.bold(`${client.guilds.size}`)} server.`)
  });
  

// คนเข้า embed
client.on("guildMemberAdd",async(member)=>{

//if (!member.client.hasPermission('SEND_MESSAGES', 'VIEW_CHANNEL')) return console.log("XDDDD");
if (!member.guild.systemChannel) return;

let embed = new Discord.RichEmbed()
    .setAuthor(`${member.user.tag} ได้เข้าดิสแล้วจ้าา`,member.guild.iconURL)
    .setColor("0xFF0092")
    .setTitle(":tada:   | สวัสดีค่ะ ")
    .setThumbnail(member.user.displayAvatarURL)
    .setDescription(`◇:cherry_blossom:-------------------------------------------:cherry_blossom:◇
[ :rice_ball: ] ยินดีต้อนรับเข้าสู่ดิสเราแล้วนะคะ 
[ :rice_ball: ] ชื่อโปรไฟล์ = **${member.user.username}**
[ :rice_ball: ] รหัสโปรไฟล์ = **${member.user.id}**
[ :rice_ball: ] แท็ก = ${member.user}
[ :rice_ball: ] จำนวนสมาชิก = **${member.guild.memberCount}**
[ :rice_ball: ] :inbox_tray: | ได้เข้าดิสแล้วจ้าา
◇:cherry_blossom:-------------------------------------------:cherry_blossom:◇`)
    .setThumbnail(member.user.displayAvatarURL)
    .setFooter('🎉ยินดีต้อนรับ')
    .setTimestamp();
member.guild.systemChannel.send(embed)
console.log(`${timestamp}${chalk.greenBright.bold('Server')}:> Member has been ${chalk.blue.bold('Joins')} in ${chalk.hex('#ffd100').bold(`${member.guild.name}`)} guild.`);
  });


// คนออก embed
client.on("guildMemberRemove",async(member)=>{

//if (!member.client.user.hasPermission('SEND_MESSAGES', 'VIEW_CHANNEL')) return console.log("XDDDD");
if (!member.guild.systemChannel) return;
  
let embed = new Discord.RichEmbed()
    .setAuthor(`${member.user.tag} ได้ออกจากดิสแล้วจ้าา`,member.guild.iconURL)
    .setTitle(":door:  | โชคดีค่ะ")
    .setColor("0xFF0092")
    .setDescription(`◇:cherry_blossom:-------------------------------------------:cherry_blossom:◇
[ :rice_ball: ] ได้ออกจากดิสไปแล้วค่ะ      
[ :rice_ball: ] ชื่อโปรไฟล์ = **${member.user.username}**
[ :rice_ball: ]  รหัสโปรไฟล์ = **${member.user.id}**
[ :rice_ball: ] แท็ก = ${member.user}
[ :rice_ball: ] จำนวนสมาชิก = **${member.guild.memberCount}**
[ :rice_ball: ] :outbox_tray: | ได้ออกดิสแล้วจ้าา
◇:cherry_blossom:-------------------------------------------:cherry_blossom:◇`)
    .setThumbnail(member.user.displayAvatarURL)
    .setFooter('🚪โชคดี')
    .setTimestamp();
member.guild.systemChannel.send(embed)
console.log(`${timestamp}${chalk.greenBright.bold('Server')}:> Member has been ${chalk.blue.bold('Leave')} in ${chalk.hex('#ffd100').bold(`${member.guild.name}`)} guild.`);
  });
      
  
client.on('message', async message => {
      
let blacklisted = ['หน้าหี','พ่อมึง','ควย','แม่มึง','หี','หำ','ไอสัส','พ่อง','เย็ด','ไอเหี้ย','กระหรี่','ควาย'] 
  
let foundInText = false;
    for (var i in blacklisted) { 
      if (message.content.toLowerCase().includes(blacklisted[i].toLowerCase())) foundInText = true;
    }
  
      if (foundInText) {
        message.delete();
        message.channel.send('ห้ามพูดคำหยาบจิไม่งันโกรธนะ 😡').then(msg => msg.delete(5000));
    }
});

client.on('message',async message => {
    if(message.author.bot){ return; }

  let keyword = ['สวัสดีมิสึฮะ','หวัดดีมิสึฮะ','ดีคับมิสึฮะ','ดีค่ะมิสึฮะ','ดีคร้าบมิสึฮะ','ดีจ้ามิสึฮะ','ดีครับมิสึฮะ']; //คำถามจากคน
  let answer = ['สวัสดีค่ะ 😊','สวัสดีจ้า 😊','หวัดดีค่ะ 😊']; //คำตอบบอท
  if(keyword.some(word => message.content.includes(word))){
     message.channel.send(`<@${message.author.id}> `+`${answer[Math.floor(Math.random()*answer.length)]}`);
  
        }
  });
  

//command by L2 edit by yuno